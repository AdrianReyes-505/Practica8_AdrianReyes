%Resolver la integral
[t,x] = ode45(@MDC,[0 10], [0 0 0]);
figure(2)
plot(t,x(:,3),'b', LineWidth=1.5);
grid on
title("Motor DC Ode45");
xlabel("Tiempo");
ylabel("Posición angular");  